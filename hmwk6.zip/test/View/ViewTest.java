package view;

/**
 * This class tests that the view is working as it should.
 */
public class ViewTest {
}
