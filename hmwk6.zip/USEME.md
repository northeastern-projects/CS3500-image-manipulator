#USE ME for jar file

* create a layer = 'create layer /name of image in res folder\\' \
  This automatically sets any layer added as whatever index # it was added
* 