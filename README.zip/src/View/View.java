package View;

public class View implements IView{

}
